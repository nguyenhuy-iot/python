# OpenCV Tutorials

Source code for the OpenCV Object Detection in Games series on the **Learn Code By Gaming** YouTube channel.

Watch the tutorials here: https://www.youtube.com/playlist?list=PL1m2M8LQlzfKtkKq2lK5xko4X-8EZzFPI
